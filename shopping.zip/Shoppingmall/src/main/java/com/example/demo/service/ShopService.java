package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Shop;

public interface ShopService {

	public Shop saveShop(Shop shop);

	public List<Shop> fetchShopList();

	public void deleteShopById(Long id);

	public Shop fetchShopById(Long id);

	public Shop updateShop(Long id, Shop shop);


}
